library(testit)

test_pkg('highr')
