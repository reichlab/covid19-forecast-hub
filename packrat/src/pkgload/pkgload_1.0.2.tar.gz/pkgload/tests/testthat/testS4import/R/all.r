setClass('derived', contains='class_to_export')

