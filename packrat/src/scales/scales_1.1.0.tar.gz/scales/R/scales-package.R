#' @keywords internal
#' @importFrom R6 R6Class
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @importFrom lifecycle deprecate_soft
## usethis namespace: end
NULL
