
readstat_error_t zsav_read_compressed_data(sav_ctx_t *ctx,
        readstat_error_t (*row_handler)(unsigned char *, size_t, sav_ctx_t *));
