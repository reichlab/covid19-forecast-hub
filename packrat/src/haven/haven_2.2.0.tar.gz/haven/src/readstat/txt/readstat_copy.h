
void readstat_copy(char *buf, size_t buf_len, const char *str_start, size_t str_len);
void readstat_copy_lower(char *buf, size_t buf_len, const char *str_start, size_t str_len);
void readstat_copy_quoted(char *buf, size_t buf_len, const char *str_start, size_t str_len);
