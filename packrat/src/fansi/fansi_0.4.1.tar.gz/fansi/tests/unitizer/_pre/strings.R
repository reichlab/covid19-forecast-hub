# Test strings for use

end <- "\033[0m"
red <- "\033[31m"
inv <- "\033[7m"
grn.bg <- "\033[42m"
rgb.und <- "\033[4;38;2;0;120;200m"
rgb.und.256 <- "\033[4;38;5;141m"
rgb.256 <- "\033[48;5;141m"


