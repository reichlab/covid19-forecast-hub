$flip2
<SQL>
SELECT `x`, `y`
FROM `df`

$flip3
<SQL>
SELECT `y`, `x`
FROM `df`

$rename
<SQL>
SELECT `x` AS `x2`
FROM `df`

