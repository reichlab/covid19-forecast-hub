
tutorialLaunchBrowser <- function(url) {
  callFun("tutorialLaunchBrowser", url)
}
