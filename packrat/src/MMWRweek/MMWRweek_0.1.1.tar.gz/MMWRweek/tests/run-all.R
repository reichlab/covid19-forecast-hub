library(testthat)
library(MMWRweek)

test_package("MMWRweek")
