library(testthat)
library(tweenr)

test_check("tweenr")
