library(markdown)

source(system.file('examples', 'markdownExtensions.R', package = 'markdown'), echo = TRUE)
source(system.file('examples', 'HTMLOptions.R', package = 'markdown'), echo = TRUE)

rm(mkd)
rm(tOpt)
